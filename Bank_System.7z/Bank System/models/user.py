from sqlalchemy import Column, Integer, String, Boolean
from sqlalchemy.orm import relationship
from config.db import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(255), unique=True, index=True)
    password = Column(String(100))
    account_number = Column(String, unique=True, default=0)
    is_admin = Column(Boolean, default=False)
    balance = Column(Integer)


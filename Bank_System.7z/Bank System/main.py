from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials,OAuth2PasswordBearer
from config.db import SessionLocal
from models.user import User
from schemas.user import UserLogin,UserRegistration,Transaction,ChangePassword,AccountDetails
from passlib.context import CryptContext
from sqlalchemy.orm import Session

app = FastAPI()

security = HTTPBasic()

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/token")


# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def verify(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password:str):
    return pwd_context.hash(password)


# Dependency to get the database session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

next_account_number = 1000


# Generate a new 4-digit account number with auto-increment
def generate_account_number():
    global next_account_number
    account_number = next_account_number
    next_account_number += 1
    return account_number

# Register a new user
@app.post("/register")
def register_user(username: str, password: str,balance: float, is_admin:bool,db:Session= Depends(get_db)):
    account_number = generate_account_number()
    hashed_password = pwd_context.hash(password)
    account = User(username=username, password=hashed_password, balance=balance, account_number=account_number, is_admin=is_admin)
    db.add(account)
    db.commit()
    db.refresh(account)
    return {"Your account_number: ": account_number}

# User login
@app.post("/login")
def login_user(credentials: HTTPBasicCredentials = Depends(security), db = Depends(get_db)):
    account = db.query(User).filter(User.username == credentials.username, User.password==credentials.password).first()
    if not account or account.password != credentials.password:
        raise HTTPException(status_code=401, detail="Invalid username or password")
    return {"account_number": account.account_number}

# User authentication dependency
def authenticate_user(credentials: HTTPBasicCredentials = Depends(security), db = Depends(get_db)):
    account = db.query(User).filter(User.username == credentials.username, User.password==credentials.password).first()
    if not account or account.password != credentials.password:
        raise HTTPException(status_code=401, detail="Invalid username or password")
    return True


# Deposit into account
@app.post("/deposit")
def deposit_money(transaction: Transaction,db = Depends(get_db)):
    account = db.query(User).filter(User.account_number == transaction.account_number).first()
    if not account:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Invalid username or password",)
    
    if not verify(transaction.password, account.password):
         raise HTTPException(
             status_code=status.HTTP_404_NOT_FOUND,
             detail="Invalid Password",
         )

    account.balance += transaction.amount
    db.add(account)
    db.commit()
    db.refresh(account)
    return {"message": "Deposit successful. New amount is ","Balance":account.balance}

# Withdraw from account
@app.post("/withdraw")
def withdraw_money(transaction: Transaction, db = Depends(get_db)):
    account = db.query(User).filter(User.account_number == transaction.account_number).first()
    if not account:
        raise HTTPException(status_code=404, detail="Account not found")

    if transaction.amount > account.balance:
        raise HTTPException(status_code=400, detail="Insufficient balance")

    if not verify(transaction.password, account.password):
         raise HTTPException(
             status_code=status.HTTP_404_NOT_FOUND,
             detail="Invalid Password",)

    account.balance -= transaction.amount
    db.commit()
    return {"message": "Withdrawal successful", "Balance":account.balance}

# Check account balance
@app.post("/balance/{account_number}")
def check_balance(details:AccountDetails, db:Session = Depends(get_db)):
    account = db.query(User).filter(User.account_number == details.account_number).first()
    if not account:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Invalid username or password",)
    
    if not verify(details.password, account.password):
         raise HTTPException(
             status_code=status.HTTP_404_NOT_FOUND,
             detail="Invalid Password",
         )

    return {"balance": account.balance}

# Change account password
@app.put("/change-password")
def change_password(password_change: ChangePassword, db = Depends(get_db)):
    account = db.query(User).filter(User.account_number == password_change.account_number).first()
    if not account:
        raise HTTPException(status_code=404, detail="Account not found")

    if not verify(password_change.current_password, account.password):
         raise HTTPException(
             status_code=status.HTTP_404_NOT_FOUND,
             detail="Invalid Password",
         )
    
    account.password = password_change.new_password
    db.commit()
    return {"message": "Password changed successfully"}

# Admin view - get all users and todos
@app.post("/admin-view", tags=["Admin Use Only"])
def admin_view(request:UserLogin, db = Depends(get_db)):
    account = db.query(User).filter(User.username == request.username).first()
    if not account:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Invalid username or password",)
    
    if not verify(request.password, account.password):
         raise HTTPException(
             status_code=status.HTTP_404_NOT_FOUND,
             detail="Invalid Password",
         )

    if account.is_admin != True:
        return {"message": "User can not access users"}
    
    users = db.query(User).all()
    return users


# Start the application
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)

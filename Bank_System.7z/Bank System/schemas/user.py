
from pydantic import BaseModel
from typing import List

class UserRegistration(BaseModel):
    username: str
    password: str
    account_number:int
    is_admin:bool
    balance:float

class UserLogin(BaseModel):
    username: str
    password: str
    is_admin:bool


class Transaction(BaseModel):
    account_number: int
    amount: int
    password: str

class ChangePassword(BaseModel):
    account_number: int
    current_password: str
    new_password: str

class AccountDetails(BaseModel):
    account_number: int
    password: str

class AdminView(BaseModel):
    users: List[AccountDetails]
    todos: List[str]

